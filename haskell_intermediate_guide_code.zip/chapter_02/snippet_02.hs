A library module that parses .md files and extracts headings/links.
