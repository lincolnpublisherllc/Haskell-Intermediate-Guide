Adding libraries: text, aeson, containers.
