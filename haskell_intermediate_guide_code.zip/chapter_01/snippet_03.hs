Recap: :: operator.
