Revisiting a simple function (add), showing how it becomes Int -> (Int -> Int).
