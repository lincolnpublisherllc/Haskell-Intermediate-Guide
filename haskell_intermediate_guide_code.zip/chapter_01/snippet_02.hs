Lists, tuples, and custom data types (quick refresher).
