Example: length :: [a] -> Int.
