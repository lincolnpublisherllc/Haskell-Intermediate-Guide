How to identify code that belongs in its own module.
