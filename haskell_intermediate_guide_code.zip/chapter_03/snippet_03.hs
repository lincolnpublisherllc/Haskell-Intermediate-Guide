module MathUtils (add, multiply) where
