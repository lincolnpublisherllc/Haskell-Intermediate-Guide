Avoiding namespace clashes with clear module boundaries.
