add :: Int -> Int -> Int
add x y = x + y
