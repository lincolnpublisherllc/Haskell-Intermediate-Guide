Anatomy of a module: module … where.
