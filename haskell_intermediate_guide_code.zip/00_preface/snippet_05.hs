Scale up into project scaffolding, dependency management, and module organization.
