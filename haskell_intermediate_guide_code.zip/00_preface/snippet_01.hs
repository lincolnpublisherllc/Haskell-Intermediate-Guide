Here is how you organize a multi-module Haskell project.
