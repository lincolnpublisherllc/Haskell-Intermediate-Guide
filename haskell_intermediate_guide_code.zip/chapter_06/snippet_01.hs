Example: safeHead :: [a] -> Maybe a.
