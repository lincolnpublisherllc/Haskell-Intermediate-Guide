Returns structured data using Either String Config.
