parseInt :: String -> Either String Int
parseInt s = case reads s of
    [(n,"")] -> Right n
    _        -> Left "Not a valid integer"
