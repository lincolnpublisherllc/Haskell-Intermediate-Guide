Write properties with QuickCheck (e.g., eval (x+y) == eval x + eval y).
