prop_reverse :: [Int] -> Bool
prop_reverse xs = reverse (reverse xs) == xs
QuickCheck automatically generates random test data.
