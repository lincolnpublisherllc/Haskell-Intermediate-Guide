import Test.Hspec
main = hspec $ do
  describe "factorial" $ do
