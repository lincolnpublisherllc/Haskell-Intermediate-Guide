safeRead :: FilePath -> IO (Either IOException String)
safeRead path = try (readFile path)
