sumLazy = foldl (+) 0 [1..1000000]  -- builds thunks
sumStrict = foldl' (+) 0 [1..1000000]  -- strict fold
