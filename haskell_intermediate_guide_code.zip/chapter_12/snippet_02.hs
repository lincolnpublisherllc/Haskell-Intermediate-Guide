Practical strategies for reducing memory: strict fields in data types, careful use of lists.
