Scotty: lightweight Sinatra-style framework.
