Serve posts via a Servant API.
Return JSON metadata with aeson.
