type API = "hello" :> Get '[JSON] String
Comparing the two: Scotty for quick prototypes, Servant for production-level APIs.
