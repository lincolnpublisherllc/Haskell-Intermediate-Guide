Megaparsec: modern, feature-rich alternative to Parsec.
