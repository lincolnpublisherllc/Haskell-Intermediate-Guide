Parses a config file (Megaparsec).
Serves a REST endpoint (Scotty).
Returns JSON responses (aeson).
