Example: choosing between Parsec and Megaparsec.
