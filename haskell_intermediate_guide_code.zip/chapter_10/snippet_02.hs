Defining a Task type and JSON instances with aeson.
