4. Defining the API with Servant
