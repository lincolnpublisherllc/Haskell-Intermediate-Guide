Explaining the Servant approach: types as contracts.
