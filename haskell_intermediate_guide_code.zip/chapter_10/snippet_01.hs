REST API with Servant (web focus).
