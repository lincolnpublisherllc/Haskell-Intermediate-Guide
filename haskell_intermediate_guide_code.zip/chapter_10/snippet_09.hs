How Servant enforces type-safe APIs.
How to integrate JSON, STM, persistence, and tests.
