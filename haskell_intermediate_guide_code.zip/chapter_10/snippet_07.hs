Returning proper HTTP error codes in Servant.
