Generating API docs with Servant.
