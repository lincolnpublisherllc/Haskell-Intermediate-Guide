Using STM (TVar) for in-memory storage.
