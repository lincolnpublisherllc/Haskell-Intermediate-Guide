Case study: Instead of Shape -> ColoredShape -> TexturedShape, compose rendering functions.
