withLogger :: Logger -> IO ()
withLogger logger = logInfo logger "Hello from DI"
