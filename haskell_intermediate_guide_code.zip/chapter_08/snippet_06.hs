Observer → STM or event streams.
