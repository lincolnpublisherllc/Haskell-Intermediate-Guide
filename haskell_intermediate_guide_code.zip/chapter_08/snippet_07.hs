In Haskell, algebraic data types + pattern matching often replace this.
