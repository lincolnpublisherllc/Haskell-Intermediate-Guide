class Drawable a where
  draw :: a -> String
