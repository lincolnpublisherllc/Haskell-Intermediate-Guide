data Circle = Circle Float
instance Drawable Circle where
  draw (Circle r) = "Circle with radius " ++ show r
