data Logger = Logger { logInfo :: String -> IO () }
