Use case: hierarchical data (file systems, syntax trees).
