import qualified Data.Set as Set
let s = Set.fromList [1,2,2,3]
-- s = fromList [1,2,3]
