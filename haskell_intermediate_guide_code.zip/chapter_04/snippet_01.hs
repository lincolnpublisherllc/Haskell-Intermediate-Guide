Use cases: returning multiple values, simple data grouping.
