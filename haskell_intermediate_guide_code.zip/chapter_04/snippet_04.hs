import qualified Data.Map as Map
phoneBook = Map.fromList [("Alice","123"),("Bob","456")]
