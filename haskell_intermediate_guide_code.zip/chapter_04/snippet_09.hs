Overusing tuples where a custom type would improve readability.
