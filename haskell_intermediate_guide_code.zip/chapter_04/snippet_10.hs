Trees are a natural recursive data structure for hierarchical data.
