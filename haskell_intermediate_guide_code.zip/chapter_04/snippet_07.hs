When immutability helps (no accidental data corruption).
