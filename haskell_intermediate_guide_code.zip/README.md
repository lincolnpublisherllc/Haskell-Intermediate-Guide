# Extracted Code Manifest

This archive was generated automatically from the uploaded DOCX.
Files are grouped by chapter. Filenames are assigned sequentially per chapter.
Extensions are guessed heuristically based on snippet content.

=== Summary ===
- 00_preface: 7 snippet(s)
- chapter_01: 4 snippet(s)
- chapter_02: 2 snippet(s)
- chapter_03: 6 snippet(s)
- chapter_04: 10 snippet(s)
- chapter_05: 10 snippet(s)
- chapter_06: 9 snippet(s)
- chapter_07: 20 snippet(s)
- chapter_08: 8 snippet(s)
- chapter_09: 8 snippet(s)
- chapter_10: 9 snippet(s)
- chapter_11: 9 snippet(s)
- chapter_12: 2 snippet(s)
- chapter_13: 5 snippet(s)
- chapter_14: 19 snippet(s)

Total snippets: 128

=== Notes ===
- Code detection used simple heuristics for Haskell-like syntax and common config formats.
- If a snippet extension looks off, feel free to rename it. The content stays intact.
- If you need me to split combined blocks into multiple files or to merge related ones, say the word.