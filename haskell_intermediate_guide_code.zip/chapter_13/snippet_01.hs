Example: replacing head with safeHead :: [a] -> Maybe a.
