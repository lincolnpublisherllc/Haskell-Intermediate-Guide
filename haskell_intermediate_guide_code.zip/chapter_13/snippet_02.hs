area :: Float -> Float
area r = pi * r^2
