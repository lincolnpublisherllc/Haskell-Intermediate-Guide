Writing module-level documentation.
