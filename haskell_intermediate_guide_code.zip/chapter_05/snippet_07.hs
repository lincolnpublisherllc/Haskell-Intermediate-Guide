data User = User { name :: String, age :: Int } deriving (Show, Generic)
instance FromJSON User
instance ToJSON User
