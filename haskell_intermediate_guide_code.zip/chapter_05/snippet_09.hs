Transform data (pure functions).
Write output JSON with aeson.
