Why streaming matters: memory efficiency when processing gigabytes of data.
