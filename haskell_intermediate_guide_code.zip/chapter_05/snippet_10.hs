How to build a simple but realistic data pipeline.
