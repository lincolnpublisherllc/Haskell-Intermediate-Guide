Why CSV is common in data pipelines.
