Beginner Haskell programs are “pure islands,” often disconnected from real-world data.
At scale, apps need to read, process, and write external data (logs, configs, datasets, API responses).
