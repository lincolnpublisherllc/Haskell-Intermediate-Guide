Introducing the aeson library.
