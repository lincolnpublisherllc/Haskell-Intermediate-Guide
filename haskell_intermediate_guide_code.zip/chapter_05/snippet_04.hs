Writing structured data back into CSV.
