JSON parsing with aeson.
