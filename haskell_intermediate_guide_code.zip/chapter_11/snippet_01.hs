Applications need persistent data and must communicate with external APIs/services.
