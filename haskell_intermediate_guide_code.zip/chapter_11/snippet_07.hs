Example: fetching data from multiple APIs concurrently.
Combine with STM for safe shared state.
