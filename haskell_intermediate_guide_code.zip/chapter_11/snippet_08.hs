Goal: combine external API data with local database storage.
