Example: fetching JSON data from an external API.
import Network.HTTP.Req
