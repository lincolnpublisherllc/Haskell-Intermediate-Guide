Fetch data from a weather API (async calls).
Store historical data in PostgreSQL.
