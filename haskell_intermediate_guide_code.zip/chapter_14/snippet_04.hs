API layer (Servant) to expose risk reports.
