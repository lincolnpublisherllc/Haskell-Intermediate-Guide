Expose a simple /risk/{id} endpoint with Servant.
