Add simple monitoring dashboard with Scotty or Servant.
