Concurrency with async or STM:
