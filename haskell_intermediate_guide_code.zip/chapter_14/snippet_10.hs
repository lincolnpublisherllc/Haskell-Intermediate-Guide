Ingest CSV of customers and loan data.
