Perfect example of leveraging strong types, concurrency, and data safety.
