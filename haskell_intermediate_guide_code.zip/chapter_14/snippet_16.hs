Advanced Concurrency: Study STM in depth and distributed systems with Cloud Haskell.
Generic Programming: Learn how libraries like aeson use GHC.Generics.
