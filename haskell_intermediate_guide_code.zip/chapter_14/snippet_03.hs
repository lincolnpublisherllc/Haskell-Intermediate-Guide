Business goal: build a system to evaluate credit risk based on input data (customers, loans, payment history).
