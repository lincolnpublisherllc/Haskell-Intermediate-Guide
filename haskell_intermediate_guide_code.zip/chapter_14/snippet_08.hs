Define endpoints with Servant:
/customers/{id} → returns customer data.
