Database: store customer and loan data in PostgreSQL.
