newtype CreditScore = CreditScore Int
newtype LoanAmount = LoanAmount Double
data Customer = Customer { name :: Text, score :: CreditScore }
