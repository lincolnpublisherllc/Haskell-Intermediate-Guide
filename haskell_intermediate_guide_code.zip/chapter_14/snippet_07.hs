Concurrency: process multiple customers in parallel using async and STM.
