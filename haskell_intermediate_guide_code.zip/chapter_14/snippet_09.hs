JSON input/output with aeson.
