REST API with Servant:
