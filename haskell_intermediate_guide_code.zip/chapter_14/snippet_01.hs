AI and data pipelines (structured data + safe transformations).
