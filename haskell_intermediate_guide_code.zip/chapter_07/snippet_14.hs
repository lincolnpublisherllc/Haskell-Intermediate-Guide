STM: composable memory transactions.
Example: TVar with atomic updates.
import Control.Concurrent.STM
