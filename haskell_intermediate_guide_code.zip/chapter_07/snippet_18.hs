Lightweight threads with forkIO.
