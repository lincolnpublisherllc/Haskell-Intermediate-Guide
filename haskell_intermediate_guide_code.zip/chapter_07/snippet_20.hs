Shared chat log managed by STM.
