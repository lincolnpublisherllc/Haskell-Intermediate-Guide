Real-world software often must do many things at once: handle clients, read files, query APIs.
