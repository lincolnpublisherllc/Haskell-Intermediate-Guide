5. Software Transactional Memory (STM)
