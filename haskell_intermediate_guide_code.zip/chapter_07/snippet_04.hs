main = do
  forkIO (putStrLn "Hello from another thread")
