Transactional memory with STM.
