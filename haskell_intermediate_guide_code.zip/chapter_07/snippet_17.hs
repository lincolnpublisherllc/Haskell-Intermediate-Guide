Store results in an STM-managed TVar.
Demonstrates async, STM, and parallel processing of tasks.
