Elixir/Erlang: actor model, message passing (similar to STM, but with distributed focus).
