forkIO: spawning a lightweight thread.
import Control.Concurrent
