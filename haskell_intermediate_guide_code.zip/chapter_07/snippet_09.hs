4. Async for Structured Concurrency
