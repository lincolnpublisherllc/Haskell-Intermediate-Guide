MVar as a mutable box for communication between threads.
