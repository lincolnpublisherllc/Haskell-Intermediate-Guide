  forkIO $ putMVar m "data from thread"
