Avoids “dangling threads” problem of raw forkIO.
